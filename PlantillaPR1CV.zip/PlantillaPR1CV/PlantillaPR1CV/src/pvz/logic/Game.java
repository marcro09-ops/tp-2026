package pvz.logic;

import pvz.control.Level;

import utils.Position;

public class Game {
	public static final int NUM_ROWS=4;
	public static final int NUM_COLS=8;
	public static final int INITIAL_COINS=50;
	private long seed;
	private Level level;
	
    public Game(long seed, Level level) {
    this.seed=seed;
    this.level=level;
   
    }
    
    public String positionToString(Position position) {
    	return "";
    }

	
}
