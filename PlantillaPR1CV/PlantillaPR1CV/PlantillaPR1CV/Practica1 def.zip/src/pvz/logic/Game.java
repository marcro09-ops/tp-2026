package pvz.logic;

import java.util.Random;

import pvz.logic.gameobjects.*;
import pvz.view.Messages;
import pvz.control.*;
import utils.Position;

public class Game {
    public static final int NUM_ROWS = 4;
    public static final int NUM_COLS = 8;
    public static final int INITIAL_COINS = 50;

    private int cycles;
    private int coins;
    private Long longSeed;
    private Random seed;
    private boolean playerQuit;
    
    private Level level;
    private PeashooterList peashooters;
    private SunflowerList sunflowers;
    private ZombiesManager zombiesManager;

    public Game(Long seed, Level level) {
        this.longSeed = seed;
        this.level = level;
        this.reset();
    }

    public void reset() {
        this.seed = new Random(this.longSeed);
        this.cycles = 0;
        this.coins = INITIAL_COINS;
        this.peashooters = new PeashooterList();
        this.sunflowers = new SunflowerList();
        this.zombiesManager = new ZombiesManager(this, this.level, this.seed);
        this.playerQuit = false;
    }

    public String positionToString(Position position) {
        String icon = this.peashooters.iconInPosition(position);
        if (icon != null && !icon.isEmpty()) return icon;

        icon = this.sunflowers.iconInPosition(position);
        if (icon != null && !icon.isEmpty()) return icon;

        return this.zombiesManager.iconInPosition(position);
    }

    public boolean checkGameObject(String objectName) {
        return objectName.equalsIgnoreCase("p") || objectName.equalsIgnoreCase("peashooter") ||
               objectName.equalsIgnoreCase("s") || objectName.equalsIgnoreCase("sunflower");
    }

    public int getCycles() {
        return this.cycles;
    }

    public int getCoins() {
        return this.coins;
    }

    public int getRemainingZombies() {
        return this.zombiesManager.getRemainingZombies();
    }

    public boolean hasGameFinished() {
        return this.playerQuit || this.playerWins() || this.zombiesManager.hasZombieReachedEnd();
    }

    public boolean playerWins() {
        return this.zombiesManager.allZombiesDead();
    }

    public boolean playerQuits() {
        return this.playerQuit;
    }

    public void quit() {
        this.playerQuit = true;
    }

    public void update() {
        
        this.sunflowers.update();
        this.peashooters.update();
        this.zombiesManager.update();
        this.zombiesManager.addZombie();
        this.peashooters.removeDead();
        this.sunflowers.removeDead();
        this.zombiesManager.removeDead();

        this.cycles++;
    }

    public void addGameObject(String plantType, Position position) {
        if (plantType.equalsIgnoreCase("p") || plantType.equalsIgnoreCase("peashooter")) {
        	if (coins < Peashooter.COST) {
                System.out.println(String.format(Messages.ERROR, Messages.NOT_ENOUGH_COINS));
                System.out.println(" ");
            }
        	
        	else {
        	this.peashooters.add(new Peashooter(position, this));
            this.buyWithCoins(Peashooter.COST);
        	}
         
        } 
        else if (plantType.equalsIgnoreCase("s") || plantType.equalsIgnoreCase("sunflower")) {
        	if (coins < Sunflower.COST) {
        		System.out.println(String.format(Messages.ERROR, Messages.NOT_ENOUGH_COINS));
        		System.out.println(" ");
            }
        	
        	else {
        	this.sunflowers.add(new Sunflower(position, this));
        	this.buyWithCoins(Sunflower.COST);
        	}
        	
        }
    }
        	   
        
    public void generateCoins(int amount) {
    	this.coins += amount;
    }

    private void buyWithCoins(int cost) {
    	this.coins -= cost;
    }


    public boolean attackZombie(Position p, int damage) {
        return this.zombiesManager.damageZombie(p, damage);
    }

    public void attackPlant(Position p, int damage) {
        this.peashooters.receiveDamage(p, damage);
        this.sunflowers.receiveDamage(p, damage);
    }

    public boolean isEmpty(Position p) {
        return this.peashooters.isEmpty(p) && 
               this.sunflowers.isEmpty(p) && 
               this.zombiesManager.isEmpty(p);
    }

    public static Position newZombiePosition(int row) {
        return new Position(NUM_COLS, row);
    }

    public boolean isInsideBoard(Position p) {
        return p.getCol() >= 0 && p.getCol() < NUM_COLS && 
               p.getRow() >= 0 && p.getRow() < NUM_ROWS;
    }
}