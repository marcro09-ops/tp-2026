package pvz.logic.gameobjects; 

import pvz.logic.Game;
import utils.Position;
import pvz.view.Messages;

public class Sunflower {

    // Constantes estáticas
    public static final int COST = 20;
    private static final int INITIAL_HEALTH = 1;
    private static final int DAMAGE = 0;
    private static final int GENERATED_SUNS = 10;
    private static final int COOLDOWN = 3;

    // Atributos
    private int health;
    private final Position position;
    private Game game;
    private int cyclesSinceLastCoinGeneration;

    // Constructor
    public Sunflower(Position position, Game g) {
        this.game=g;
        this.position=position;
        this.health=INITIAL_HEALTH;
        this.cyclesSinceLastCoinGeneration=0;
        
    }

    // Métodos de la clase
    public String getIcon() {
        
        return String.format(
        		Messages.SUNFLOWER_ICON,
        		this.health);
    }

    public boolean isInPosition(Position position) {
    	 if (position == null) return false;
         return this.position.equals(position);
    }

    public static String getDescription() {
        
        return String.format(
        		Messages.SUNFLOWER_DESCRIPTION,
        		COST,
        		DAMAGE,
        		INITIAL_HEALTH);
    }
    
    public boolean isAlive() {
        // TODO: Implementar
        return this.health>0;
    }

    public void update() {
    	
        if(cyclesSinceLastCoinGeneration==COOLDOWN) {//Da soles después  de tres ciclos, no al tercero
        	game.generateCoins(GENERATED_SUNS); //Añade coins al total de coins
        	cyclesSinceLastCoinGeneration=1;
        	
        }
        else{
        	cyclesSinceLastCoinGeneration++;
        }
        
    }

    public void receiveDamage(int damage) {
        health-=damage;
    }

    public static String shortName() {
    	return "S";
    }
    
    public static String longName() {
    	return "Sunflower";
    }

   
}