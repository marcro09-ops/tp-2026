package pvz.logic.gameobjects; // Ajusta el paquete según la estructura de tu proyecto

import pvz.logic.gameobjects.Sunflower;

import utils.Position;

public class SunflowerList {

    // Atributos de instancia
    private int numberOfSunflowers;
    private Sunflower[] sunflowers;

    // Constructor
    public SunflowerList() {
    	this.numberOfSunflowers=0;
    	this.sunflowers = new Sunflower[32];
    }
    
    
    private void removeFromIndex(int index) {
    	for(int i=index+1; i<this.numberOfSunflowers; i++) { //Quita de la lista los girasoles muertos y reordena
    		this.sunflowers[i-1]=this.sunflowers[i];
    	}
    	numberOfSunflowers--;
    }
    
    public String iconInPosition(Position position) {
        for (int i = 0; i < numberOfSunflowers; i++) {
            if (sunflowers[i].isInPosition(position)) {
                return sunflowers[i].getIcon();
            }
        }
        return "";
    }
    
    public boolean isEmpty(Position position) {
        for (int i = 0; i < numberOfSunflowers; i++) {
            if (sunflowers[i].isInPosition(position)) {
                return false;
            }
        }
        return true; 
    }
    
    public void removeDead() {
        for(int i=0; i<numberOfSunflowers; i++) {
        	if(!sunflowers[i].isAlive()) {
        		removeFromIndex(i);
        	}
        }
    }
    


    public void update() {
    	for(int i=0; i<numberOfSunflowers; i++) {
        	sunflowers[i].update();
        }
    }

    // Métodos de la clase
    public void add(Sunflower sunflower) { //PREGUNTAR
    	if(numberOfSunflowers<sunflowers.length) {
    		sunflowers[numberOfSunflowers]=sunflower;
            numberOfSunflowers++;
    	}
        
        
    }

    public void receiveDamage(Position position, int damage) {
        for (int i = 0; i < numberOfSunflowers; i++) {
            if (sunflowers[i].isInPosition(position)) {
                sunflowers[i].receiveDamage(damage);
                return; 
            }
        }
    }
}
