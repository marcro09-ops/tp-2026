package pvz.logic.gameobjects;
import utils.Position;

public class PeashooterList {
    private int numberOfPeashooters;
    private Peashooter[] peashooters;

    public PeashooterList() {
        this.numberOfPeashooters = 0;
        // game col y row o con 32 vale.
        this.peashooters = new Peashooter[32]; 
    }

    public void add(Peashooter p) {
        if (this.numberOfPeashooters < this.peashooters.length) {
            this.peashooters[this.numberOfPeashooters] = p;
            this.numberOfPeashooters++;
        }
    }

    public void update() {
        // La actualización de los objetos se realiza estrictamente en el orden 
        // en el que fueron añadidos al tablero[cite: 3].
        for (int i = 0; i < this.numberOfPeashooters; i++) {
            this.peashooters[i].update();
        }
    }

    public String iconInPosition(Position position) {
        for (int i = 0; i < this.numberOfPeashooters; i++) {
            if (this.peashooters[i].isInPosition(position)) {
                return this.peashooters[i].getIcon();
            }
        }
        return "";
    }

    public boolean isEmpty(Position position) {
        for (int i = 0; i < this.numberOfPeashooters; i++) {
            if (this.peashooters[i].isInPosition(position)) {
                return false; // La posición está ocupada
            }
        }
        return true;
    }

    public void receiveDamage(Position position, int damage) {
        for (int i = 0; i < this.numberOfPeashooters; i++) {
            if (this.peashooters[i].isInPosition(position)) {
                this.peashooters[i].receiveDamage(damage);
                return; // Una vez dañado, se detiene la búsqueda
            }
        }
    }

    public void removeDead() {
        // Los objetos muertos deben eliminarse después de la fase de actualización, 
        // nunca durante la misma, para no alterar los índices que se están recorriendo.
        for (int i = 0; i < this.numberOfPeashooters; i++) {
            if (!this.peashooters[i].isAlive()) {
                removeFromIndex(i);
                // Decrementar 'i' es obligatorio porque al desplazar el array, 
                // el siguiente elemento pasa a ocupar la posición actual.
                i--; 
            }
        }
    }

    private void removeFromIndex(int index) {
        // Desplazamiento manual del array para rellenar el hueco dejado por la planta eliminada.
        for (int i = index; i < this.numberOfPeashooters - 1; i++) {
            this.peashooters[i] = this.peashooters[i + 1];
        }
        this.peashooters[this.numberOfPeashooters - 1] = null;
        this.numberOfPeashooters--;
    }
}
