package pvz.logic.gameobjects; // Ajusta el paquete según la estructura de tu proyecto

import pvz.logic.gameobjects.Zombie;

import utils.Position;

public class ZombieList{

    // Atributos de instancia
	
    private int numberOfZombies;
    private Zombie[] zombies;

    // Constructor
    public ZombieList() {
    	this.numberOfZombies=0;
    	this.zombies = new Zombie[32];
    }
    
    
    private void removeFromIndex(int index) {
    	for(int i=index+1; i<this.numberOfZombies; i++) {
    		this.zombies[i-1]=this.zombies[i];
    	}
    	numberOfZombies--;
    }
    
    public int size() {
    	return this.numberOfZombies;
    }
    
    public String iconInPosition(Position position) {
        for (int i = 0; i < numberOfZombies; i++) {
            if (zombies[i].isInPosition(position)) {
                return zombies[i].getIcon();
            }
        }
        return "";
    }
    
    public boolean isEmpty(Position position) {
        for (int i = 0; i < numberOfZombies; i++) {
            if (zombies[i].isInPosition(position)) {
                return false;
            }
        }
        return true; 
    }
    
    public boolean add(Zombie zombie) { //PREGUNTAR
    	if(numberOfZombies<zombies.length) {
    		zombies[numberOfZombies]=zombie;
            numberOfZombies++;
            return true;
    	}
    	else {
    		return false;
    	}
        
        
    }
    
    public boolean receiveDamage(Position position, int damage) {
        for (int i = 0; i < this.numberOfZombies; i++) {
            if (this.zombies[i].isInPosition(position)) {
                this.zombies[i].receiveDamage(damage);
                return true; // Una vez aplicas el daño a la planta correcta, cortas la ejecución
            }
        }
        return false;
    }
    
    
    public void update() {
    	for(int i=0; i<this.numberOfZombies; i++) {
        	zombies[i].update();
        }
    }
    
    public void removeDead() {
        for(int i=0; i<this.numberOfZombies; i++) {
        	if(!zombies[i].isAlive()) {
        		removeFromIndex(i);
        		i--;
        	}
        }
    }
    
    public boolean anyInColumn(int col) {
        // Creamos una posición de referencia en esa columna (la fila no importa si solo evalúa la columna)
        Position posReferencia = new Position(col, 0);

        for (int i = 0; i < this.numberOfZombies; i++) {
            // Le preguntamos directamente al zombie si coincide en columna con esa posición
            if (this.zombies[i].isVerticallyAligned(posReferencia)) {
                return true;
            }
        }
        return false;
    }
   

  
}