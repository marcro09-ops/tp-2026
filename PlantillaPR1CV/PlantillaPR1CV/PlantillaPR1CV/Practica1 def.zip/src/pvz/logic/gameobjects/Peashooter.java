package pvz.logic.gameobjects;
import pvz.view.Messages;
import utils.Position;
import pvz.logic.Game;

public class Peashooter {
    public static final int COST = 50;
    private static final int DAMAGE = 1;
    private static final int INITIAL_HEALTH = 3;

    private int health;
    private final Position position;
    private Game game;

    public Peashooter(Position position, Game game) {
        this.position = position;
        this.game = game;
        this.health = INITIAL_HEALTH;
    }

    public String getIcon() {
    	return String.format(
        		Messages.PEASHOOTER_ICON,
        		this.health);
    }

    public boolean isInPosition(Position position) {
        if (position == null) return false;
        return this.position.equals(position);
    }

    public static String getDescription() {
        // [P]eashooter: cost='50' suncoins, damage='1', endurance='3'
    	 return String.format(
         		Messages.PEASHOOTER_DESCRIPTION,
         		COST,
         		DAMAGE,
         		INITIAL_HEALTH);
    }

    public boolean isAlive() {
        return this.health > 0;
    }

    public void update() {
    	if (this.isAlive()) {
    	    this.shoot();
    	   }
    }

    private void shoot() {
        boolean zombieHit = false;
        int i = this.position.getCol() + 1;
        while (i < Game.NUM_COLS && !zombieHit) {
            Position p = new Position(i, this.position.getRow());
            zombieHit = this.game.attackZombie(p, DAMAGE);
            i++;
        }
    }

    public void receiveDamage(int damage) {
        this.health -= damage;
    }

    public static String shortName() {
        return "P";
    }

    public static String longName() {
        return "Peashooter";
    }
}

