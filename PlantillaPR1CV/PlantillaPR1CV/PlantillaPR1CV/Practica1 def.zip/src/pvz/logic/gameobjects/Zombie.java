package pvz.logic.gameobjects; // Ajusta el paquete según la estructura de tu proyecto

import pvz.logic.Game;

import pvz.view.Messages;
import utils.Position;

public class Zombie {

    // Constantes estáticas (Atributos de clase)
	private static final int INITIAL_HEALTH = 5;
    private static final int DAMAGE = 1;
    private static final int MOVE_EVERY_CYCLES = 2;

    // Atributos de instancia
    private int health;
    private int cyclesToNextMovement;
    private Position position;
    private Game game;

    // Constructor
    public Zombie(Position position, Game g) {
    	this.game=g;
    	this.position=position;
        this.health=INITIAL_HEALTH;
        this.cyclesToNextMovement=MOVE_EVERY_CYCLES;
    }
    
    public String getIcon() {
        
        return String.format(Messages.ZOMBIE_ICON, this.health);
    }

    // Métodos de la clase
    public boolean isInPosition(Position position) {
    	 if (position == null) {
    		 return false;
    	 }
         return this.position.equals(position);
    }

    public boolean isHorizontallyAligned(Position position) {
        // TODO: Implementar
    return this.position.isHorizontallyAligned(position);
    }

    public boolean isVerticallyAligned(Position position) {
        // TODO: Implementar
    	return this.position.isVerticallyAligned(position);
    }

    public void receiveDamage(int damage) {
        
    	this.health-=damage;
    }

    public void update() {
        // TODO: Implementar
    	
    	
    	if(canMove()) {//CONSULTAR!!!!!!!
    		if(cyclesToNextMovement==1) {
            	
                move();
            	cyclesToNextMovement=MOVE_EVERY_CYCLES;
            }
    		
            else {
            	cyclesToNextMovement--;
            }
    	}
    	else {
            	
            	attack();
           
    	}
    	
    }
    
    private boolean canMove() {
    	return game.isEmpty(position.left());
    }
    
    private void move() {
    	this.position=position.left();
    }
    
    private void attack() {
    	game.attackPlant(position.left(), DAMAGE);
    }

    public boolean isAlive() {
        // TODO: Implementar
    	
    	return this.health>0;
    }

}
