package pvz.logic;

import java.util.Random;

import pvz.control.Level;
import pvz.logic.gameobjects.Zombie;
import pvz.logic.gameobjects.ZombieList;
import utils.Position;

/**
 * Manages the full lifecycle of zombies for a game session.
 *
 * <p>Responsibilities: deciding each cycle whether to spawn a new zombie
 * (probabilistically, subject to the remaining quota from {@link Level}),
 * delegating per-cycle updates and dead-removal to the underlying
 * {@link ZombieList}, and answering win/loss queries
 *
 */
public class ZombiesManager {

	private Game game;

	private Level level;

	private Random rand;

	private int remainingZombies;

	private ZombieList zombies;

	public ZombiesManager(Game game, Level level, Random rand) {
		this.game = game;
		this.level = level;
		this.rand = rand;
		this.remainingZombies = level.getNumberOfZombies();
		this.zombies = new ZombieList();
	}

	/**
	 * Checks if the game should add (if possible) a zombie to the game.
	 * 
	 * @return <code>true</code> if a zombie should be added to the game.
	 */
	public boolean shouldAddZombie() {
		return rand.nextDouble() < level.getZombieFrequency();
	}
	
	/**
	 * Return a random row within the board limits.
	 * 
	 * @return a random row.
	 */
	private int randomZombieRow() {
		return rand.nextInt(Game.NUM_ROWS);
	}
	
	public boolean addZombie() {
		int row = randomZombieRow();
		return addZombie(row);
	}

	public boolean addZombie(int row) {
		Position zombiePosition = Game.newZombiePosition(row);
		boolean probabilidad = shouldAddZombie();

		boolean canAdd = this.remainingZombies > 0 && probabilidad
				&& game.isEmpty(zombiePosition);

		if (canAdd) {
		    this.zombies.add(new Zombie(zombiePosition, this.game));
		    this.remainingZombies--;
		}
		return canAdd;
	}
	
	public int getRemainingZombies() {
		return remainingZombies;
	}
	
	public boolean hasZombieReachedEnd() {
		return zombies.anyInColumn(-1);
	}
	
	public boolean damageZombie(Position p, int damage) {
	    return zombies.receiveDamage(p, damage);
	}
	
	public String iconInPosition(Position p) {
		return zombies.iconInPosition(p);
	}
	
	public boolean isEmpty(Position p) {
		return zombies.isEmpty(p);
	}
	
	public void update() {
		zombies.update();
	}
	
	public boolean allZombiesDead() {
		return this.remainingZombies == 0 && this.zombies.size() == 0;
	}
	
	public void removeDead() {
		zombies.removeDead();
	}

	// TODO fill your code
}
