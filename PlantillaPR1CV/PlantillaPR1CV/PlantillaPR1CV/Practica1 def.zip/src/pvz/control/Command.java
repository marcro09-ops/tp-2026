package pvz.control;

public enum Command {
	 NONE,
	    EXIT,
	    RESET,
	    LIST,
	    HELP,
	    ADD,
	    INVALID
}
