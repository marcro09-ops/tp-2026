package pvz.control;

import pvz.logic.Game;


import pvz.logic.Game;
import utils.Position;
import pvz.logic.gameobjects.Peashooter;
import pvz.logic.gameobjects.Sunflower;
import pvz.view.GamePrinter;
import pvz.view.GameView;
import pvz.view.Messages;
import pvz.control.Command;



/**
 * Input/output coordinator of the game (the C in MVC).
 *
 * <p>Owns the game loop: reads a line from stdin, parses it into a
 * command, validates parameters (plant type, position), delegates
 * state changes to {@link Game}, and triggers a board reprint via
 * {@link tp1.pvz.view.GameView>} when the cycle advances. It holds no game
 * state of its own; the source of truth is always {@link Game}.
 */


public class Controller {

	private final Game game;
	private final GameView view;

	public Controller(Game game) {
		this.game = game;
		this.view = new GamePrinter(game);
	}

	/**
	 * Runs the game logic.
	 */
	private Command parseUserInput(String[] words) {
		Command c;
		if (words == null || words.length == 0 || words[0].isEmpty()) {
            return Command.NONE;
        }
		switch(words[0].toLowerCase()) {
		case "n":
        case "none":
            c=Command.NONE;
            break;

        case "e":
        case "exit":
            c=Command.EXIT;
            break;

        case "r":
        case "reset":
            c=Command.RESET;
            
            
            break;

        case "l":
        case "list":
            // Invoca los métodos estáticos para mostrar la información
            c=Command.LIST;
            break;

        case "h":
        case "help":
            c=Command.HELP;
            break;

        case "a":
        case "add":
		    c=Command.ADD;
		    break;
        default:
            c=Command.INVALID;
		}
		return c;
	}
	
	private boolean isValidPosition(Position position) {
		
		return this.game.isInsideBoard(position) && this.game.isEmpty(position);
	}
	
	private boolean isValidGameObject(String objectName) {
		return game.checkGameObject(objectName);
	}
	
	public void run() {
        // Se pinta el tablero inicial antes de entrar al bucle
        this.view.showGame();

        // Bucle principal: se ejecuta mientras el juego no haya finalizado
        while (!this.game.hasGameFinished()) {
            String[] words=this.view.getPrompt(); 
            
            // Si el jugador pulsa Enter sin escribir nada, equivale al comando 'none'
            

            // Permite introducir comandos completos o solo la primera letra, ignorando mayúsculas
            Command command = parseUserInput(words);
            boolean updateCycle = false;

            switch (command) {
                case NONE:
                    updateCycle = true;
                    break;

                case EXIT:
                    this.game.quit();
                    break;

                case RESET:
                    this.game.reset();
                    // Al reiniciar, se vuelve a mostrar el tablero inicial en el ciclo 0
                    this.view.showGame();
                    break;

                case LIST:
                    // Invoca los métodos estáticos para mostrar la información
                    this.view.showMessage(Messages.LIST);
                    break;

                case HELP:
                    this.view.showMessage(Messages.HELP);
                    break;
                case ADD:
                    if (words.length < 4) {
                        this.view.showError(Messages.COMMAND_PARAMETERS_MISSING); // Reemplaza con Messages.XXX
                    } else {
                        String plantType = words[1];
                        try {
                            int col = Integer.parseInt(words[2]);
                            int row = Integer.parseInt(words[3]);
                            Position p = new Position(col, row);

                            // Validaciones estrictas antes de intentar añadir
                            if (!isValidPosition(p)) {
                                this.view.showError(String.format(Messages.INVALID_POSITION)); 
                            } else if (!isValidGameObject(plantType)) {
                                this.view.showError(String.format(Messages.INVALID_GAME_OBJECT));
                            }
                            else {
                                // Si todo es correcto, se añade y el ciclo avanza
                                this.game.addGameObject(plantType, p);
                                updateCycle = true;
                            }
                        } catch (NumberFormatException ex) {
                            this.view.showError("Invalid coordinates");
                        }
                    }
                    break;

                case INVALID:
                    this.view.showError(Messages.INVALID_COMMAND);
                    break;
            }

            // El update y repintado solo se desencadena con un add exitoso o un none
            if (updateCycle && !this.game.hasGameFinished()) {
                this.game.update();
                this.view.showGame();
            }
        }
        
        // Al terminar el bucle, se muestra el mensaje de victoria/derrota
        this.view.showEndMessage();
    }

}